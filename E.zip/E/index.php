<?php
  require_once("./Includes/top.php");
?>
<body>
 <!--start here main wrapper area-->
  <div id="wrapper">
      <!--start here main header area -->
      <div id="header">
        <?php
            require_once("./Includes/header.php");
          ?>
      </div>
      <!--/end here main header area-->
       <!--start here main content area-->
      <div  id="content" >
        <!--start here main center area-->
        <div id="center">
             <!--start here main slider area-->
              <div class="slider">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                     <span>
                         <p><a href="#">festival offer <br><strong>SALE</strong></a></p>
                         
                     </span>
                      <img class="d-block w-100" src="./Image/slider/5.jpg" alt="First slide">
                      <div class="bottom-banner" class="d-block w-100">
                          <ul>
                              <li>PRODUCT TITLE</li>
                              <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras suscipit lacus dapibus ante mattis in adipiscing nibh placerat. Cras bibendum porta diam, non dignissim sapien malesuada vitae. </li>
                          </ul>
                      </div>
                    </div>
                     <div class="carousel-item">
                     <span>
                         <p><a href="#">festival offer <br><strong>SALE</strong></a></p>
                         
                     </span>
                      <img class="d-block w-100" src="./Image/slider/5.jpg" alt="First slide">
                      <div class="bottom-banner" class="d-block w-100">
                          <ul>
                              <li>PRODUCT TITLE</li>
                              <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras suscipit lacus dapibus ante mattis in adipiscing nibh placerat. Cras bibendum porta diam, non dignissim sapien malesuada vitae. </li>
                          </ul>
                      </div>
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
          </div>
          <!--/end here main slider area-->
          <div class="content_panel">
              <div class="left_panel">
                 <?php
                  require_once("./Includes/left-panel.php"); 
                 ?>
              </div>
              <div class="right_section">
                 <div class="order">
                 <div class="sort-by pull-left">
                     <form action="">
                           <span class="fa fa-3x">sort by  :</span>
                            <select name="" id="order" >
                                <option value="Ascending">Ascending</option>
                                <option value="descending">Descending</option>
                            </select>
                            <select name="" id="Brand_Name" >
                              <option value="1">Brand Name</option>
                            </select>
                    </form>
                 </div>
                 <div class="sort pull-right fa fa-3x">
                     Items Per page 12/20 30/50 
                 </div> 
             </div>
                 <div class="heading">
                     <h1><strong>OUR PRODUCTS</strong></h1>
                 </div>
                 <ul class="total-product-list">
                      <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/12.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/11.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/10.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/9.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/8.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/7.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/6.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/5.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/4.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/3.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/2.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                      </li>
                           <li class="product">
                         <ul>
                             <li>
                                 <img src="./Image/home/1.png" alt="">
                             </li>
                         </ul> 
                          <ul class="name">
                             <li class="price">Product Name</li>
                             <li  class="price">Product Price: $12.90</li>
                         </ul> 
                         <ul class="detail">
                             <li><a href=""><i class="fa fa-shopping-cart"></i> add to cart</a></li>
                             <li><a href="">Details</a></li>
                         </ul>
                     </li>
                  </ul>
                 <div class="pagination">
                      <ul class="page">
                          <li class="items"><a href="#">1</a></li>
                          <li class="items"><a href="#">2</a></li>
                          <li class="items"><a href="#">3</a></li>
                          <li class="items"><a href="#">4</a></li>
                          <li class="items"><a href="#">5</a></li>
                          <li class="items"><a href="#">Next</a></li>
                          <li class="items"><a href="#">Previous</a></li>
                          <li class="items"><a href="#">>></a></li>
                      </ul>
                  </div>
                 <div class="feature-items">
                      <div class="heading">
                          <h1><strong>FEATURED PRODUCTS</strong></h1>
                      </div>
                      <div class="carousel-items">
                          <div class="owl-carousel parent ">
                                <div class="box">
                                    <li>
                                       <a href="#">
                                            <img src="./Image/cart/one.png" alt="">
                                            <p>High resolution abstract bokeh background</p>
                                        </a>
                                    </li>
                                </div>
                                 <div class="box">
                                       <li>
                                       <a href="#">
                                            <img src="./Image/cart/two.png" alt="">
                                            <p>High resolution abstract bokeh background</p>
                                        </a>
                                    </li>
                                </div>
                                 <div class="box">
                                     <li>
                                       <a href="#">
                                            <img src="./Image/cart/three.png" alt="">
                                            <p>High resolution abstract bokeh background</p>
                                        </a>
                                    </li>
                                </div>
                                 <div class="box">
                                     <li>
                                       <a href="#">
                                            <img src="./Image/cart/one.png" alt="">
                                            <p>High resolution abstract bokeh background</p>
                                        </a>
                                    </li>
                                </div>
                        </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>   
        <!--/end here main center area-->
      </div>
      <!--/end here main content area-->
       <!--start here main footer  area-->
      <div id="footer">
         <?php
            require_once("./Includes/footer.php"); 
          ?>
  </div>
   <!--/end here main wrapper area-->
</body>
</html>