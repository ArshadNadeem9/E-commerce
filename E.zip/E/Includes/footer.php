 <div class="secure">
              <ul>
                  <li><a href="#"><img src="./Image/home/secure_1.png" alt="">Shop online with us safely & securely</a> </li>
                  <li><a href="#"><img src="./Image/home/secure_2.png" alt="">We ship your orders anywhere !</a> </li>
                  <li><form action="">
                      <input type="search" id="search" placeholder="search website" tabindex="1"><input type="submit" value="GO" tabindex="2">
                  </form></li>
              </ul>
          </div>
          <div class="extra-info">
                 <ul>
                     <li class="footer-bottom-detail">
                         <h1>Company</h1>
                         <ul>
                             <li><a href="#">HOME</a></li>
                             <li><a href="#">ABOUT US</a></li>
                             <li><a href="#">Latest News</a></li>
                             <li><a href="#">BLOG</a></li>
                             <li><a href="#">LOGIN</a></li>
                             <li><a href="#">JOIN US</a></li>
                         </ul>
                     </li>
                     <li class="footer-bottom-detail"  >
                           <h1>Categories</h1>
                           <ul>
                               <li><a href="#">Lorem ipsum dolor sit </a></li>
                               <li><a href="#">Amet consectetur </a></li>
                               <li><a href="#">Adipiscin elit </a></li>
                               <li><a href="#">Cras suscipit lacus </a></li>
                               <li><a href="#">Dapibus ante mattis </a></li>
                               <li><a href="#">Adipiscing nibh placerat </a></li>
                           </ul>
                     </li>
                     <li class="footer-bottom-detail"  class="justify">
                           <h1>Information</h1>
                           <ul>
                               <li><a href="#">My Account</a></li>
                               <li><a href="#">Rewards</a></li>
                               <li><a href="#">Terms & Conditions</a></li>
                               <li><a href="#">Buying Guide</a></li>
                               <li><a href="#">FAQ</a></li>
                               <li><a href="#"></a></li>
                               <li><a href="#"></a></li>
                               <li><a href="#"></a></li>
                           </ul>
                     </li>
                     <li class="footer-bottom-detail" class="justify">
                           <h1>Social Network</h1>
                           <ul>
                               <li><a href="#">My Account</a></li>
                               <li><a href="#">Rewards</a></li>
                               <li><a href="#">Terms & Conditions</a></li>
                               <li><a href="#">Buying Guide</a></li>
                               <li><a href="#">FAQ</a></li>
                           </ul>
                     </li>
                     <li class="footer-bottom-detail" class="justify">
                           <h1>Contact Us</h1>
                           <ul>
                               <li>Phone: 1.234.567.8901</li>
                               <li>Toll-Free: 1.234.567.8901</li>
                               <li>Fax: 1.234.567.8901</li>
                               <li>Email: Send us an email</li>
                               <li>MON - SAT 	9am to 7:30pm</li>
                               <li>Sundays, holidays closed</li>
                           </ul>
                     </li>
                 </ul>
             </div>
      </div>
      <!--/end here main footer area-->
      <!--start here main footer library of jquery and bootstrap link area-->
      <div>
          <script src="./Js/jquery-3.4.1.min.js"></script>
          <script src="./Js/bootstrap-4.3.1.min.js"></script>
          <script src="Assets/owl.carousel.js"></script>
          <script>
            $('.owl-carousel').owlCarousel({
                loop:true,
                margin:10,
                nav:true,
                item:3,
                autoplay:1000,
            });
          </script>
      </div>
     <!--end here main footer library of jquery and bootstrap link area-->