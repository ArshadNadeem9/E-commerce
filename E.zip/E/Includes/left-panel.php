  <div class="category">
                            <h1>Browse Categories</h1>
                      <ul>
                          <li><a href="">Lorem ipsum dolor sit </a></li>
                          <li><a href="">Amet consectetur  </a></li>
                          <li><a href="">Adipiscin elit </a></li>
                          <li><a href="">Cras suscipit lacus  </a></li>
                          <li><a href="">Dapibus ante mattis  </a></li>
                          <li><a href="">Adipiscing nibh placerat </a></li>
                          <li><a href="">Cras bibendum </a></li>
                          <li><a href="">Porta diam elit </a></li>
                          <li><a href="">Adipiscing nibh placerat </a></li>
                          <li><a href="">Cras bibendum  </a></li>
                          <li><a href="">Porta diam elit </a></li> 
                      </ul>
                  </div>
                  <div class="social-info">
                       <div class="inner_social_info">
                             <p>Join our newsletter list
to get the latest updates</p>
                     <form action="">
                         <div class="form-group">
                             <input type="email" name="email" class="form-control">
                         </div>
                         <div >
                             <input type="submit" name="sumbit" value="Join Now" id="submit">
                         </div>
                     </form>
                      <ul>
                        <li><a href=""><img src="./Image/socials/twitter.png" alt="">Follow us on Twitter</a></li>
				        <li><a href=""><img src="./Image/socials/facebook.png" alt="">Become our fan
on Facebook</a></li>
				        <li><a href=""><img src="./Image/socials/linkedln.png" alt="">Connect with us
on LinkedIn</a></li>
				        <li><a href=""><img src="./Image/socials/message.png" alt="">Send us your
email enquiries</a></li>
				       
                      </ul>
                       </div>
                  </div>
                  <div class="payment">
                     <ul>
                          <li><a href=""><img src="./Image/payment_methods/PayPal.png" alt=""></a></li>
                          <li><a href=""><img src="./Image/payment_methods/Google%20checkout.png" alt=""></a></li>
                          <li><a href=""><img src="./Image/payment_methods/mcf.png" alt=""></a></li>
                        
                      </ul>
                  </div>