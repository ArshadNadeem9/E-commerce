 <header class="header-area">
             <div class="header-first">
                <ul>
                     <ul class="user_menus">
                     <li><a href="#"><i class="fa fa-lock"></i> sign In</a></li>
                     <li><a href="#"><i class="fa fa-sign-in"></i>Register</a></li>
                     <li><a href="#">buyer Guide</a></li>
                     <li><a href="#">About Us</a></li>
                     <li><a href="#">Blog</a></li>
                     <li><a href="#">Contact Us</a></li>
                 </ul>
                 <ul class="user-help">
                     <li><a href="#"><i class="fa fa-phone"></i>+1 2345 234</a></li>
                     <li><a href="#"><i class="fa fa-comment"></i>live Help</a></li>
                     <li><a href="#"><img src="./Image/flag.png" alt=""></a></li>
                     <li><a href="#"><img src="./Image/flag_2.png" alt=""></a></li>
                 </ul>
                </ul>
             </div>
             <div class="header-second">
                  <ul>
                      <li class="logo-area">
                          <img src="./Image/logo.png" alt="logo" >
                      </li>
                       <li>
                           <ul>
                               <li><a href="#"><i class="fa fa-shopping-cart"></i>cart</a></li>
                               <li><a href="#"><i class="fa fa-crosshairs"></i>Check Out</a></li>
                           </ul>
                       </li>
                        
                      <li class="third-child">
                          <strong> ECOMMERCE </strong><br>WEBSITE
                      </li>
                      <li>
                           <input type="search" name="search" id="search-bar" placeholder="search here product">
                           <input type="submit" name="sumbit"  value="GO">
                      </li>
                  </ul>
             </div>
             <div class="header-third">
                    <ul>
                        <li><a href="#">HOME</a></li>
                        <li><a href="#">LATEST ARRIVALS</a></li>
                        <li><a href="#">MEN'S</a></li>
                        <li><a href="#">WOMEN'S</a></li>
                        <li><a href="#">KIDS</a></li>
                        <li><a href="#">BRANDS</a></li>
                        <li><a href="#">SALE</a></li>
                        <li><a href="#">GIFT CARD</a></li>
                    </ul>
             </div> 
          </header>