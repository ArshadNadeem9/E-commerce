<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="keyword" conten="This ECommerce website online and shipping goods etc">
    <meta name="description" conten="This ECommerce website online and shipping goods like a  T-shirt bags andriod mobile desktop others part things etc">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,shrink-to-fit=yes">
    <meta http-equiv="content-type" content="text/HTML">
    <!--bootstrap-->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="./css/font-awesome.css" media="all">
   <link rel="stylesheet" href="./css/style.css"/>
   <link rel="stylesheet" href="./css/bootstrap-4.3.1.min.css"/>
   <link rel="stylesheet" href="./Assets/assets/owl.carousel.css">
    <title>E-Shopper || HOME Page</title>
</head>