<?php
 require_once('./Includes/top.php');
?>
<body>
     <div id="wrapper">
      <!--start here main header area -->
      <div id="header">
        <?php
            require_once("./Includes/header.php");
          ?>
      </div>
      <!--/end here main header area-->
       <!--start here main content area-->
      <div  id="content" >
        <!--start here main center area-->
        <div id="center">
        </div>
        <!--/ end here main center area-->
      </div>
      <!--/ end here main content area-->
    
      <!--start here main footer area-->
        <div id="footer">
         <?php
            require_once("./Includes/footer.php"); 
          ?>
        
      <!--/ end here main footer area-->
   
 </div>
   <!--/end here main wrapper area-->
</body>
</html>